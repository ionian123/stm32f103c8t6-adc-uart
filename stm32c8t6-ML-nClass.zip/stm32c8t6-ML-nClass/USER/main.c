#include "stdio.h"
#include "stm32f10x.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"
#include "stm32f10x_adc.h"
#include "stm32f10x_usart.h"
#include "delay.h"
#include "usart.h"
/* Includes --------------------------------------------------------------------*/
/* Includes --------------------------------------------------------------------*/
#include "NanoEdgeAI.h"
#include "knowledge.h"
/* Private define --------------------------------------------------------------*/
/* Private variables defined by user -------------------------------------------*/
float input_user_buffer[DATA_INPUT_USER * AXIS_NUMBER]; // Buffer of input values
float output_class_buffer[CLASS_NUMBER]; // Buffer of class probabilities

void ADC_Configuration(void);
void USART_Configuration(void);
void USART_Send(uint16_t data);
void putstring(uint8_t *s);
void GPIO_Config(void);
void ADC_Configuration(void);
void ADC_Read();
void fill_buffer(float input_buffer[]);

uint16_t adcValue[6] = {0};  // 6 channel ADC

int main()
{
	uint32_t i;
	char SIM[32] = {0};
	char nclass[6] = {0};
	//delay_ms(5000);
    // 初始化 ADC、USART
	ADC_DeInit(ADC1);
	ADC_Configuration();
    //USART_Configuration();
	uart_init(9600);		
	SystemInit();
	GPIO_Config();
	delay_init();
	ADC_Configuration();		
		/* Initialization ------------------------------------------------------------*/
	enum neai_state error_code = neai_classification_init(knowledge);
	if (error_code != NEAI_OK) {
		/* This happens if the knowledge does not correspond to the library or if the library works into a not supported board. */
	}

	/* Classification ------------------------------------------------------------*/
	uint16_t id_class = 0;
    while(1)
    {
		GPIO_SetBits(GPIOB, GPIO_Pin_0);
		fill_buffer(input_user_buffer);//float input_user_buffer[DATA_INPUT_USER * AXIS_NUMBER]; 256*6
		neai_classification(input_user_buffer, output_class_buffer, &id_class);
		/* USER BEGIN */
			sprintf(SIM,"%.4f %.4f %.4f",output_class_buffer[0],output_class_buffer[1],output_class_buffer[2]);
            
			sprintf(nclass,"%u",id_class);
			putstring(SIM);putstring("\t");
			putstring(nclass);putstring("\n");
        switch(id_class)
			{
                case 1: putstring("Straight");GPIO_ResetBits(GPIOC, GPIO_Pin_13);
                    break;
                case 2: putstring("Curve-under");GPIO_SetBits(GPIOC, GPIO_Pin_13);
                    break;
                case 3: putstring("Curve-over");GPIO_SetBits(GPIOC, GPIO_Pin_13);
                    break;
            }
			
			GPIO_ResetBits(GPIOB, GPIO_Pin_0);
			
		}
	}

void ADC_Configuration(void)
{
   //ADC1初始化
	// ADC1、ADC2时钟使能
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1 | RCC_APB2Periph_ADC2, ENABLE);
    
   	// GPIOA、GPIOB时钟使能
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB, ENABLE);
	
		GPIO_InitTypeDef GPIO_InitStructure;
    // 初始化6Channel ADC1  PA0-PA5
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5 ;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;  // 模拟输入
	GPIO_Init(GPIOA, &GPIO_InitStructure);
		
	ADC_InitTypeDef ADC_InitStructure;
    // ADC1模式设置
    ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;  // 独立工作模式
    ADC_InitStructure.ADC_ScanConvMode = DISABLE;  // 关扫描
    ADC_InitStructure.ADC_ContinuousConvMode = DISABLE;  // 关连续工作
    ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;  
    ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;  
    ADC_InitStructure.ADC_NbrOfChannel = 6;  // 6 Channel
    ADC_Init(ADC1, &ADC_InitStructure);
    
	ADC_Cmd(ADC1, ENABLE);
	// ADC1使能
    ADC_ResetCalibration(ADC1);
    while (ADC_GetResetCalibrationStatus(ADC1));  // 校准
	ADC_StartCalibration(ADC1);
    while (ADC_GetCalibrationStatus(ADC1));  
		
	//设置通道采样顺序
	ADC_RegularChannelConfig(ADC1, ADC_Channel_0, 1, ADC_SampleTime_55Cycles5);  // PA0
    ADC_RegularChannelConfig(ADC1, ADC_Channel_1, 2, ADC_SampleTime_55Cycles5);  // PA1
	ADC_RegularChannelConfig(ADC1, ADC_Channel_2, 3, ADC_SampleTime_55Cycles5);  // PA2
	ADC_RegularChannelConfig(ADC1, ADC_Channel_3, 4, ADC_SampleTime_55Cycles5);  // PA3
	ADC_RegularChannelConfig(ADC1, ADC_Channel_4, 5, ADC_SampleTime_55Cycles5);  // PA4
	ADC_RegularChannelConfig(ADC1, ADC_Channel_5, 6, ADC_SampleTime_55Cycles5);  // PA5  
}


void ADC_Read(void) 
{
	ADC_RegularChannelConfig(ADC1, ADC_Channel_0, 1, ADC_SampleTime_55Cycles5);  // PA0
    // Channel 0
    ADC_SoftwareStartConvCmd(ADC1, ENABLE);
    while (!ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC));
	adcValue[0] = ADC_GetConversionValue(ADC1);  
		
		
	ADC_RegularChannelConfig(ADC1, ADC_Channel_1, 1, ADC_SampleTime_55Cycles5);  // PA1
    // Channel 1
    ADC_SoftwareStartConvCmd(ADC1, ENABLE);
    while (!ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC));
	adcValue[1] = ADC_GetConversionValue(ADC1);  
	
	
	ADC_RegularChannelConfig(ADC1, ADC_Channel_2, 1, ADC_SampleTime_55Cycles5);  // PA2
    // Channel 2
    ADC_SoftwareStartConvCmd(ADC1, ENABLE);
    while (!ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC));
	adcValue[2] = ADC_GetConversionValue(ADC1); 
	
	
	ADC_RegularChannelConfig(ADC1, ADC_Channel_3, 1, ADC_SampleTime_55Cycles5);  // PA3
    // Channel 3
    ADC_SoftwareStartConvCmd(ADC1, ENABLE);
    while (!ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC));
	adcValue[3] = ADC_GetConversionValue(ADC1);  
		
		
	ADC_RegularChannelConfig(ADC1, ADC_Channel_4, 1, ADC_SampleTime_55Cycles5);  // PA4
    // Channel 4
    ADC_SoftwareStartConvCmd(ADC1, ENABLE);
    while (!ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC));
	adcValue[4] = ADC_GetConversionValue(ADC1);  
		
		
	ADC_RegularChannelConfig(ADC1, ADC_Channel_5, 1, ADC_SampleTime_55Cycles5);  // PA5
    // Channel 5
    ADC_SoftwareStartConvCmd(ADC1, ENABLE);
    while (!ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC));
	adcValue[5] = ADC_GetConversionValue(ADC1); 
        
}
		
/*void USART_Configuration(void)//自定义初始化UART，有BUG
{
    // GPIOA 
    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;// USART1 TX
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;// USART1 RX
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    //  USART
    USART_InitTypeDef USART_InitStructure;
    USART_InitStructure.USART_BaudRate = 9600;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
    USART_Init(USART1, &USART_InitStructure);
		
    // USART1 、GPIOA 使能
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1 | RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO, ENABLE);
    USART_Cmd(USART1, ENABLE);
}
*/
void USART_Send(uint16_t data)
{
    // uint16_t
    USART_SendData(USART1, data);
    while(USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET);
}

void GPIO_Config(void) //自定义GPIO初始化
{
    
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;            
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;     
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;    
    GPIO_Init(GPIOC, &GPIO_InitStructure);        

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;            
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;     
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;    
    GPIO_Init(GPIOB, &GPIO_InitStructure);  	
}

void fill_buffer(float input_buffer[])//ADC to NetInput
{
    for (int i = 0; i < 256; i++) 
	{
		ADC_Read();
        input_buffer[i * 6 + 0] = (float)adcValue[0];
        input_buffer[i * 6 + 1] = (float)adcValue[0] / 2;
        input_buffer[i * 6 + 2] = (float)adcValue[0] / 3;
        input_buffer[i * 6 + 3] = (float)adcValue[0] / 4;
        input_buffer[i * 6 + 4] = (float)adcValue[0] / 5;
        input_buffer[i * 6 + 5] = (float)adcValue[0] / 6;
    }
}





